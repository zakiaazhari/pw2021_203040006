<?php 

$data = array('buah1' => 'anggur', 'buah2' => 'mangga', 'buah3' => 'melon');

?>