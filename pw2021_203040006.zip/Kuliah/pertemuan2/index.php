<?php
/*
Zaki Auliya Azhari
203040006
https://github.com/zakiaazhari/pw2021_203040006.
Pertemuan 2 - 11 Februarari 2021
Mempelajari mengenai Sintaks Dasar PHP
*/
?>
<?php
// Standar Output
// echo, print
?>
