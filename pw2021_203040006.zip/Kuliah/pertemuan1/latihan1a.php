<?php for ($x=1; $x<=3; $x++){
    for ($z=1; $z<=3; $z++){
        echo "Ini perulangan ke ($x,$z)<br>";
    }
}
?>